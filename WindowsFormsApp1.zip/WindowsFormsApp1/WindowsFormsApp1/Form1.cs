﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using Microsoft.TeamFoundation.WorkItemTracking.WebApi;
using Microsoft.TeamFoundation.WorkItemTracking.WebApi.Models;
using Microsoft.VisualStudio.Services.Common;


namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        readonly string _uri;
        readonly string _personalAccessToken;
        readonly string _project;

        public Form1()
        {
            InitializeComponent();
            _uri = "http://vsalm:8080/tfs/FabrikamFiberCollection";
            _personalAccessToken = "personal access token";
            _project = "FabrikamFiber";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            RunGetBugsQueryUsingClientLib();
        }

        /// <summary>
        /// Execute a WIQL query to return a list of bugs using the .NET client library
        /// </summary>
        /// <returns>List of Microsoft.TeamFoundation.WorkItemTracking.WebApi.Models.WorkItem</returns>
        public List<WorkItem> RunGetBugsQueryUsingClientLib()
        {
            Uri uri = new Uri(_uri);
            string personalAccessToken = _personalAccessToken;
            string project = _project;

            VssCredentials credentials = new VssCredentials();
            //create instance of work item tracking http client
            WorkItemTrackingHttpClient workItemTrackingHttpClient = new WorkItemTrackingHttpClient(uri, credentials);

            //create a wiql object and build our query
            Wiql wiql = new Wiql()
            {
                Query = "Select [State], [Title] " +
                        "From WorkItems " +
                        "Where [Work Item Type] = 'Bug' " +
                        "And [System.TeamProject] = '" + project + "' " +
                        "And [System.State] <> 'Closed' " +
                        "Order By [State] Asc, [Changed Date] Desc"
            };
            List<QueryHierarchyItem> queryHierarchyItems = workItemTrackingHttpClient.GetQueriesAsync(_project, depth: 1).Result;
            QueryHierarchyItem sharedQueriesFolder = queryHierarchyItems.FirstOrDefault(qhi => qhi.Name.Equals("Shared Queries"));
            QueryHierarchyItem productBacklog = sharedQueriesFolder.Children.FirstOrDefault(qhi => qhi.Name.Equals("Product Backlog"));

            using (workItemTrackingHttpClient)
            {
                //execute the query to get the list of work items in the results
                WorkItemQueryResult workItemQueryResult = workItemTrackingHttpClient.QueryByIdAsync(productBacklog.Id).Result;

                //some error handling                
                if (workItemQueryResult.WorkItemRelations.Count() != 0)
                {
                    //need to get the list of our work item ids and put them into an array
                    List<int> list = new List<int>();
                    foreach (var item in workItemQueryResult.WorkItemRelations)
                    {
                        list.Add(item.Target.Id);
                    }
                    int[] arr = list.ToArray();

                    //build a list of the fields we want to see
                    string[] fields = new string[3];
                    fields[0] = "System.Id";
                    fields[1] = "System.Title";
                    fields[2] = "System.State";

                    //get work items for the ids found in query
                    var workItems = workItemTrackingHttpClient.GetWorkItemsAsync(arr, fields, workItemQueryResult.AsOf).Result;

                    Console.WriteLine("Query Results: {0} items found", workItems.Count);

                    //loop though work items and write to console
                    foreach (var workItem in workItems)
                    {
                        Console.WriteLine("{0}          {1}                     {2}", workItem.Id, workItem.Fields["System.Title"], workItem.Fields["System.State"]);
                    }

                    return workItems;
                }

                return null;
            }
        }

    }
}
